package com.inacap.fyagobras.factura;

import com.inacap.fyagobras.domain.audit.AuditoriaService;
import com.inacap.fyagobras.domain.cliente.Cliente;
import com.inacap.fyagobras.domain.factura.EstadoPago;
import com.inacap.fyagobras.domain.factura.Factura;
import com.inacap.fyagobras.domain.factura.FacturaService;
import com.inacap.fyagobras.domain.factura.dto.EmitirFacturaDTO;
import com.inacap.fyagobras.domain.factura.dto.RegistrarPagoDTO;
import com.inacap.fyagobras.domain.factura.repository.FacturaRepository;
import com.inacap.fyagobras.domain.factura.validation.create.MontoNoExcedeSaldo;
import com.inacap.fyagobras.domain.factura.validation.create.ObraFinalizada;
import com.inacap.fyagobras.domain.factura.validation.pago.FacturaPendiente;
import com.inacap.fyagobras.domain.factura.validation.pago.FechaPagoValida;
import com.inacap.fyagobras.domain.obra.EstadoObra;
import com.inacap.fyagobras.domain.obra.Obra;
import com.inacap.fyagobras.domain.obra.repository.ObraRepository;
import com.inacap.fyagobras.domain.presupuesto.Presupuesto;
import com.inacap.fyagobras.domain.presupuesto.dto.ItemPresupuestoDTO;
import com.inacap.fyagobras.domain.servicio.TipoServicio;
import com.inacap.fyagobras.domain.user.Role;
import com.inacap.fyagobras.domain.user.Usuario;
import com.inacap.fyagobras.infra.exception.ConflictoNegocioException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * CP: Facturar obra no finalizada y pagar dos veces una factura.
 * Trazabilidad: HU-13, HU-14, RF-04. Tipo: funcional. Herramienta: JUnit 5 (automatizada).
 *
 * FacturaService recibe sus validadores como listas inyectadas por Spring. Aquí se arman
 * con los validadores reales (ObraFinalizada, MontoNoExcedeSaldo, FacturaPendiente, FechaPagoValida)
 * y repositorios simulados, de modo que se prueban las reglas de negocio de verdad.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("Facturación y pago de facturas (HU-13 / HU-14 / RF-04)")
// Prueba el registro de cobros y los calculos asociados a las facturas.
class FacturaCobroTest {

    // Identificadores y fechas fijos usados en los escenarios de facturación.
    private static final Long OBRA_ID = 100L;
    private static final Long FACTURA_ID = 500L;
    private static final LocalDate EMISION = LocalDate.of(2026, 11, 1);
    private static final LocalDate VENCIMIENTO = LocalDate.of(2026, 12, 1);
    private static final LocalDate PAGO = LocalDate.of(2026, 11, 10);

    // Repositorios simulados para consultar obras y facturas.
    @Mock private FacturaRepository facturaRepository;
    @Mock private ObraRepository obraRepository;
    @Mock private AuditoriaService auditoriaService;

    // Servicio construido manualmente porque los validadores deben controlarse en la prueba.
    private FacturaService service;
    // Usuario financiero que ejecuta la emisión o el pago.
    private Usuario actor;

    @BeforeEach
    void preparar() {
        // Prepara el validador que exige una obra finalizada.
        var obraFinalizada = new ObraFinalizada();
        ReflectionTestUtils.setField(obraFinalizada, "repository", obraRepository);

        // Prepara el validador que impide exceder el saldo facturable.
        var montoSaldo = new MontoNoExcedeSaldo();
        ReflectionTestUtils.setField(montoSaldo, "obraRepository", obraRepository);
        ReflectionTestUtils.setField(montoSaldo, "facturaRepository", facturaRepository);

        // Construye el servicio y conecta sus dependencias manualmente.
        service = new FacturaService();
        ReflectionTestUtils.setField(service, "facturaRepository", facturaRepository);
        ReflectionTestUtils.setField(service, "obraRepository", obraRepository);
        ReflectionTestUtils.setField(service, "auditoriaService", auditoriaService);
        // Usa las reglas reales de emisión y pago dentro de la prueba.
        ReflectionTestUtils.setField(service, "emitirValidador", List.of(obraFinalizada, montoSaldo));
        ReflectionTestUtils.setField(service, "pagoValidador",
                List.of(new FacturaPendiente(), new FechaPagoValida()));

        // Crea el usuario autenticado con rol FINANZAS.
        actor = new Usuario();
        actor.setId(2L);
        actor.setRole(Role.FINANZAS);
    }

    private static Obra obra(EstadoObra estado) {
        // Construye el cliente asociado al presupuesto.
        var cliente = new Cliente();
        cliente.setId(1L);
        cliente.setRazonSocial("Constructora Andes SpA");

        // Crea y aprueba el presupuesto usado por la obra.
        var presupuesto = new Presupuesto("PRES-000001", cliente,
                List.of(new ItemPresupuestoDTO("Instalación", new BigDecimal("200000"))));
        ReflectionTestUtils.setField(presupuesto, "id", 10L);
        presupuesto.aprobar();

        // Crea el tipo de servicio y asigna sus identificadores.
        var tipo = new TipoServicio("Instalación eléctrica");
        ReflectionTestUtils.setField(tipo, "id", 3L);

        // Construye la obra y asigna el identificador esperado.
        var obra = new Obra("Instalación bodega", "Obra de prueba",
                LocalDate.of(2026, 10, 1), presupuesto, tipo, null);
        ReflectionTestUtils.setField(obra, "id", OBRA_ID);
        // Cambia el estado artificialmente cuando el escenario lo requiere.
        if (estado != EstadoObra.EN_PROCESO) {
            obra.cambiarEstado(estado, "motivo de prueba");
        }
        return obra;
    }

    private static EmitirFacturaDTO datosFactura() {
        // Devuelve los datos comunes de emisión de factura.
        return new EmitirFacturaDTO(OBRA_ID, EMISION, VENCIMIENTO, new BigDecimal("200000"));
    }

    // ---------- HU-13: emitir factura ----------

    @Test
    @DisplayName("Con la obra FINALIZADA se emite la factura con número automático y estado PENDIENTE")
    void obraFinalizadaSeFactura() {
        // Simula una obra finalizada y saldo todavía disponible.
        when(obraRepository.findById(OBRA_ID)).thenReturn(Optional.of(obra(EstadoObra.FINALIZADA)));
        when(facturaRepository.totalFacturadoObra(OBRA_ID)).thenReturn(BigDecimal.ZERO);
        when(facturaRepository.siguienteNumero()).thenReturn(1L);
        // Asigna el identificador generado al guardar la factura.
        when(facturaRepository.save(any(Factura.class))).thenAnswer(inv -> {
            Factura f = inv.getArgument(0);
            ReflectionTestUtils.setField(f, "id", FACTURA_ID);
            return f;
        });

        // Ejecuta la emisión con los datos preparados.
        var resultado = service.emitir(datosFactura(), actor);

        // Verifica los datos principales y el estado inicial de la factura.
        assertThat(resultado.id()).isEqualTo(FACTURA_ID);
        assertThat(resultado.numeroFactura()).isEqualTo("F-0001");
        assertThat(resultado.estadoPago()).isEqualTo(EstadoPago.PENDIENTE);
        assertThat(resultado.anulada()).isFalse();
        assertThat(resultado.fechaPago()).isNull();
        // Comprueba que se registre la emisión en auditoría.
        verify(auditoriaService).registrar(eq(actor), eq("facturas"), eq(FACTURA_ID),
                eq("EMITIR_FACTURA"), isNull(), isNull(), anyMap());
    }

    @Test
    @DisplayName("Con la obra EN_PROCESO no se puede facturar")
    void obraNoFinalizadaNoSeFactura() {
        // Simula una obra todavía en proceso.
        when(obraRepository.findById(OBRA_ID)).thenReturn(Optional.of(obra(EstadoObra.EN_PROCESO)));

        // Ejecuta la emisión y verifica la excepción de estado.
        assertThatThrownBy(() -> service.emitir(datosFactura(), actor))
                .isInstanceOf(ConflictoNegocioException.class)
                .hasMessage("Solo se puede facturar una obra en estado FINALIZADA.");

        // Confirma que no se guarde ni audite la operación rechazada.
        verify(facturaRepository, never()).save(any(Factura.class));
        verify(auditoriaService, never()).registrar(any(), any(), any(), any(), any(), any(), any());
    }

    @Test
    @DisplayName("Con la obra SUSPENDIDA tampoco se puede facturar")
    void obraSuspendidaNoSeFactura() {
        // Simula una obra suspendida.
        when(obraRepository.findById(OBRA_ID)).thenReturn(Optional.of(obra(EstadoObra.SUSPENDIDA)));

        // Comprueba que el estado suspendido tampoco permite facturar.
        assertThatThrownBy(() -> service.emitir(datosFactura(), actor))
                .isInstanceOf(ConflictoNegocioException.class)
                .hasMessage("Solo se puede facturar una obra en estado FINALIZADA.");

        // Verifica que no se genere una factura.
        verify(facturaRepository, never()).save(any(Factura.class));
    }

    @Test
    @DisplayName("No se puede facturar más que el saldo por facturar de la obra")
    void noSePuedeFacturarMasQueElSaldo() {
        // Simula una obra finalizada con parte de su presupuesto ya facturado.
        when(obraRepository.findById(OBRA_ID)).thenReturn(Optional.of(obra(EstadoObra.FINALIZADA)));
        when(facturaRepository.totalFacturadoObra(OBRA_ID)).thenReturn(new BigDecimal("150000"));

        // Intenta emitir 200000 sobre solo 50000 disponibles y verifica el rechazo.
        assertThatThrownBy(() -> service.emitir(datosFactura(), actor))
                .isInstanceOf(ConflictoNegocioException.class)
                .hasMessageContaining("supera el saldo");

        // Confirma que no se persista ni audite la factura inválida.
        verify(facturaRepository, never()).save(any(Factura.class));
        verify(auditoriaService, never()).registrar(any(), any(), any(), any(), any(), any(), any());
    }

    // ---------- HU-14: registrar pago ----------

    private Factura facturaPendiente() {
        // Construye una factura pendiente asociada a una obra finalizada.
        var f = new Factura("F-0001", obra(EstadoObra.FINALIZADA), EMISION, VENCIMIENTO,
                new BigDecimal("200000"));
        ReflectionTestUtils.setField(f, "id", FACTURA_ID);
        return f;
    }

    @Test
    @DisplayName("Una factura PENDIENTE se paga y queda PAGADO con su fecha de pago")
    void facturaPendienteSePaga() {
        // Prepara una factura pendiente y simula su búsqueda.
        var factura = facturaPendiente();
        when(facturaRepository.findById(FACTURA_ID)).thenReturn(Optional.of(factura));

        // Registra el pago usando la fecha establecida.
        var resultado = service.registrarPago(FACTURA_ID, new RegistrarPagoDTO(PAGO), actor);

        // Comprueba el estado pagado y la fecha guardada.
        assertThat(resultado.estadoPago()).isEqualTo(EstadoPago.PAGADO);
        assertThat(resultado.fechaPago()).isEqualTo(PAGO);
        // Verifica la auditoría del pago.
        verify(auditoriaService).registrar(eq(actor), eq("facturas"), eq(FACTURA_ID),
                eq("REGISTRAR_PAGO"), isNull(), anyMap(), anyMap());
    }

    @Test
    @DisplayName("Una factura PAGADA no se vuelve a pagar: el segundo pago se rechaza y no cambia nada")
    void facturaPagadaNoSePagaDosVeces() {
        // Prepara una factura pendiente y realiza el primer pago.
        var factura = facturaPendiente();
        when(facturaRepository.findById(FACTURA_ID)).thenReturn(Optional.of(factura));

        service.registrarPago(FACTURA_ID, new RegistrarPagoDTO(PAGO), actor);

        // Intenta registrar un segundo pago en una fecha posterior.
        var segundoPago = new RegistrarPagoDTO(PAGO.plusDays(5));
        assertThatThrownBy(() -> service.registrarPago(FACTURA_ID, segundoPago, actor))
                .isInstanceOf(ConflictoNegocioException.class)
                .hasMessage("La factura ya se encuentra pagada.");

        // Comprueba que siga pagada con la fecha del primer pago.
        assertThat(factura.getEstadoPago()).isEqualTo(EstadoPago.PAGADO);
        assertThat(factura.getFechaPago()).isEqualTo(PAGO);
        // Confirma que el primer pago produjo exactamente una auditoría.
        verify(auditoriaService, times(1)).registrar(any(), eq("facturas"), eq(FACTURA_ID),
                eq("REGISTRAR_PAGO"), any(), anyMap(), anyMap());
    }
}